
public class Test {

	public static void main(String[] args) {
		ReservationSystemUI obj = new ReservationSystemUI();
		obj.start();
	}
}
