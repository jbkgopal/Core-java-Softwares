import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class ReservationSystemUI {
	private ReservationSystem reservationSystem = new ReservationSystem();

	public void start() {
		  
		System.err.println("\n\t\t\t<============Develop By GopalSing Girase=============>\n");
		System.out.println("\t\t--------------------Online Guest House Rooms Reservation-----------------");
		System.out.println("\t\t\t\t\t " + "  " + "XMJW+J96, Ferns City,");
		System.out.println("\t\t\t\t77/987 Doddanekkundi, Bengaluru,");
		System.out.println("\t\t\t\t\t" + "    " + "Karnataka 560048\n");
		System.out.println("GSTIN: 03AWBPP8756K592" + "\t\t\t\t\t\t\tContact: (+91) 7709373709");
		// format of date and time
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date2 = new Date();
		Calendar calendar = Calendar.getInstance();
		String[] days = new String[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
		// prints current date and time
		System.out.println("Date: " + formatter.format(date2) + "  " + days[calendar.get(Calendar.DAY_OF_WEEK) - 1]
				+ "\t\t\t\t\t\t (+91) 8007317529\n");
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Online Guest House Rooms Reservation");
		System.err.println("Please Enter Your Choice");
		
		while (true) {
			System.out.println("1. Make a reservation");
			System.out.println("2. View all reservations");
			System.out.println("3. Cancel a reservation");
			System.out.println("4. Exit");

			int choice = scanner.nextInt();
			scanner.nextLine();

			switch (choice) {
			case 1:
				System.out.print("Name: ");
				String name = scanner.nextLine();
				System.out.print("Date: ");
				String date = scanner.nextLine();
				System.out.print("Number of guests: ");
				int numberOfGuests = scanner.nextInt();
				scanner.nextLine();

				Reservation reservation = reservationSystem.makeReservation(name, date, numberOfGuests);
				System.out.println("Reservation made with ID " + reservation.getId());
				break;
			case 2:
				System.out.println("Reservations:");
				for (Reservation r : reservationSystem.getReservations()) {
					System.out.println(
							r.getId() + " - " + r.getName() + " - " + r.getDate() + " - " + r.getNumberOfGuests());
				}
				break;
			case 3:
				System.out.print("Reservation ID to cancel: ");
				int id = scanner.nextInt();
				scanner.nextLine();

				if (reservationSystem.cancelReservation(id)) {
					System.out.println("Reservation canceled");
				} else {
					System.out.println("Reservation not found");
				}
				break;
			case 4:
				return;
			default:
				System.out.println("Invalid choice");
			}

			System.out.println();
		}
	}

	
}