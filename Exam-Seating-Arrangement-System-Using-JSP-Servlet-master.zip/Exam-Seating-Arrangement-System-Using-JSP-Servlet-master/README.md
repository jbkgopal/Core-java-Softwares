# Exam-Seating-Arrangement-System-Using-JSP-Servlet
This web project build using Netbeans IDE. Frame Work use Java Servlet and Jsp. Database Mysql.

Installation instructions ==>

1.	install netbeans.(NetBeans IDE 8.0.2) or other version
2.	install mysql database password (apcl123456) that use in project (you can also change project password see point 13,14)
3.	mysql workbench

Database Configure  ==>

4.	open mysql workbench 
5.	unzip the project folder(ESRS.zip)
6.	open btrs.sql from ESRS\DatabaseScript\esas.sql) location
7.	copy all file text and past it in mysql Workbance workspace and run it      
8.	now esas database in available in database

Project Configure  ==>

9.	open netbeans IDE
10.	GlassFish server by default add in netbeans, if not add GlassFish server
11.	Open project in netbeans from (ESRS\Project) location
12.	for change database password, host or anything
13.	open Connect Class from com package
14.	now change batabase configure what you want
15.	run project.

Porject Login  ==>

16.	username = admin
	password = test

